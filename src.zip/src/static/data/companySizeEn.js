export const companySizeJsonEn = [
    {
        label: "Less than 20",
        value: "TYPE1",
        children: []
    },
    {
        label: "20-99",
        value: "TYPE2",
        children: []
    },
    {
        label: "100-499",
        value: "TYPE3",
        children: []
    },
    {
        label: "500-999",
        value: "TYPE4",
        children: []
    },
    {
        label: "1000-9999",
        value: "TYPE5",
        children: []
    },
    {
        label: "More than 10000",
        value: "TYPE6",
        children: []
    }
];