export const companyTypeJson = [
    {
        label: "国企",
        value: "国企",
        children: []
    },
    {
        label: "外商独资",
        value: "外商独资",
        children: []
    },
    {
        label: "代表处",
        value: "代表处",
        children: []
    },
    {
        label: "合资",
        value: "合资",
        children: []
    },
    {
        label: "民营",
        value: "民营",
        children: []
    },
    {
        label: "股份制企业",
        value: "股份制企业",
        children: []
    },
    {
        label: "上市公司",
        value: "上市公司",
        children: []
    },
    {
        label: "国家机关",
        value: "国家机关",
        children: []
    },
    {
        label: "事业单位",
        value: "事业单位",
        children: []
    },
    {
        label: "其他",
        value: "其他",
        children: []
    }
];