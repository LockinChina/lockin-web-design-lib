export const companyTypeJsonEn = [
    {
        label: "State-owned enterprise",
        value: "国企",
        children: []
    },
    {
        label: "Wholly foreign-owned",
        value: "外商独资",
        children: []
    },
    {
        label: "Representative office",
        value: "代表处",
        children: []
    },
    {
        label: "Joint venture enterprise",
        value: "合资",
        children: []
    },
    {
        label: "Private enterprise",
        value: "民营",
        children: []
    },
    {
        label: "Joint-equity enterprise ",
        value: "股份制企业",
        children: []
    },
    {
        label: "Listed company ",
        value: "上市公司",
        children: []
    },
    {
        label: "Government agency",
        value: "国家机关",
        children: []
    },
    {
        label: "Listed company",
        value: "事业单位",
        children: []
    },
    {
        label: "Other",
        value: "其他",
        children: []
    }
];