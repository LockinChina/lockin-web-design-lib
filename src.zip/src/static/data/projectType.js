export const projectTypeJson = [
    {
        label: "全职",
        value: "全职",
        children: []
    },
    {
        label: "实习",
        value: "实习",
        children: []
    },
    {
        label: "其他",
        value: "其他",
        children: []
    }
];