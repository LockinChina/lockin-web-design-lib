export const companySizeJson = [
    {
        label: "20人以下",
        value: "TYPE1",
        children: []
    },
    {
        label: "20-99人",
        value: "TYPE2",
        children: []
    },
    {
        label: "100-499人",
        value: "TYPE3",
        children: []
    },
    {
        label: "500-999人",
        value: "TYPE4",
        children: []
    },
    {
        label: "1000-9999人",
        value: "TYPE5",
        children: []
    },
    {
        label: "10000人以上",
        value: "TYPE6",
        children: []
    }
];